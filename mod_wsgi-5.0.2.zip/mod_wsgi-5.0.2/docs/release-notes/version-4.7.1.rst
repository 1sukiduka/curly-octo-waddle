=============
Version 4.7.1
=============

Version 4.7.1 of mod_wsgi can be obtained from:

  https://codeload.github.com/GrahamDumpleton/mod_wsgi/tar.gz/4.7.1

Bugs Fixed
----------

* Fix up installation on Windows into a virtual environment when
  using latest ``virtualenv`` version, or recent Python versions
  with the bundled ``venv`` module for creating virtual environments.
